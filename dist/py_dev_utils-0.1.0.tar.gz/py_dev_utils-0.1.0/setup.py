# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['py_dev_utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'py-dev-utils',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jon T',
    'author_email': 'jjt@tutanota.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
